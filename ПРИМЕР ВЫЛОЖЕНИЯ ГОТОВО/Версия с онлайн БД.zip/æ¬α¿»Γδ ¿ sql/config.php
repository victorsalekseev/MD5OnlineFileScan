<?php
Error_Reporting(1+2+4);
define("DBName","aver");
define("dbHostName","localhost");
define("dbUserName","root");
define("dbPassword","adminadmin");
define("tbl_fileinfo","fileinfo");


//$page_size = 10;//Записей на странице
$theme = 'default';//тема
$site_url = 'svn.1io.ru';//'FileInfo.rootkits.ru';
